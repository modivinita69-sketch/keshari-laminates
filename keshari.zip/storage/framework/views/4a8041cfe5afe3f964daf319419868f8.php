

<?php $__env->startSection('title', 'Brands'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Brands</h1>
    <div>
        <a href="<?php echo e(route('admin.brands.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Add Brand
        </a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0"><i class="bi bi-tags"></i> Brand List</h5>
    </div>
    <div class="card-body p-0">
        <?php if($brands->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th width="80">Logo</th>
                            <th>Name</th>
                            <th>Categories</th>
                            <th>Products</th>
                            <th>Status</th>
                            <th width="150">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($brand->logo): ?>
                                    <img src="<?php echo e(asset('storage/' . $brand->logo)); ?>" 
                                         alt="<?php echo e($brand->name); ?>" 
                                         class="img-thumbnail"
                                         style="width: 50px; height: 50px; object-fit: contain;">
                                <?php else: ?>
                                    <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                         style="width: 50px; height: 50px;">
                                        <i class="bi bi-building text-muted"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="fw-semibold"><?php echo e($brand->name); ?></div>
                                <?php if($brand->description): ?>
                                    <small class="text-muted"><?php echo e(Str::limit($brand->description, 50)); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $brand->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-secondary"><?php echo e($category->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo e($brand->products->count()); ?> products</span>
                            </td>
                            <td>
                                <?php if($brand->is_active): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.brands.edit', $brand)); ?>" 
                                       class="btn btn-outline-primary" 
                                       title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form method="POST" 
                                          action="<?php echo e(route('admin.brands.destroy', $brand)); ?>" 
                                          class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this brand?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-tags display-1 text-muted"></i>
                <h5 class="mt-3">No Brands Found</h5>
                <p class="text-muted">
                    Start by adding your first brand.
                    <a href="<?php echo e(route('admin.brands.create')); ?>" class="btn btn-link">Add Brand</a>
                </p>
            </div>
        <?php endif; ?>
    </div>
    <?php if($brands->hasPages()): ?>
        <div class="card-footer">
            <?php echo e($brands->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\keshari\resources\views\admin\brands\index.blade.php ENDPATH**/ ?>